<?php

namespace App\Exceptions;

class AlreadySyncedException extends \Exception
{

}