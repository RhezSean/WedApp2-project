<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gadget extends Model
{
    protected $fillable = ['name'];
}
