@extends('layouts.master')

@section('content')

    <div class="container">


        <h1>Terms of Service</h1>
        <hr>
        <div><h2>1. Introduction</h2>
            <p>

               INTRODUCTIONS

            </p>

        </div>

        <br><br>
    </div>

@endsection
