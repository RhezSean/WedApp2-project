<link href="{{ elixir('css/all.css') }}" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="/css/sweetalert.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
