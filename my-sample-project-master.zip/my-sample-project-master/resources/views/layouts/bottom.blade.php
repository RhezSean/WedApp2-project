<hr>
<div class="well">
    <p>&copy;

        @if (date('Y') > 2015)
            2015 - {{ date('Y') }}

        @else

            2015

        @endif

        My Sample Project All rights Reserved 2017
        	Rhez Sean H. Crisostomo   .</p>
</div>