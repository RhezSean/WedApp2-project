
<script src="{{ elixir('js/app.js') }}"></script>
<!--sweet alert  -->
<script src="/js/sweetalert.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.3/Chart.min.js"></script>