@extends('layouts.master')

@section('content')
<div class ="container">

    <div class="alert alert-danger alert-dismissible alert-important" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        Your Transaction Failed!
    </div>

</div>
@endsection